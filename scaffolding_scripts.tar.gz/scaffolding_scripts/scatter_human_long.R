input=read.table("human_long_results.csv",sep=",");
colors=c("cyan","seagreen","black","red","blue","seagreen1","magenta","brown","orange","azure4");
for(i in 1:nrow(input))
{
	if(input[i,3]==3)
	{
		input[i,3]=15;
	}
	else if(input[i,3]==1)
	{
		input[i,3]=16;
	}
	else if(input[i,3]==2)
	{
		input[i,3]=17;
	}
	else if(input[i,3]==4)
	{
		input[i,3]=18;
	}
	else if(input[i,3]==5)
	{
		input[i,3]=1;
	}
}
postscript("scatter_human_long.eps");

plot(input[,4],input[,5],lwd=2,pch=input[,3],col=colors[input[,2]],xlab="# Correct joins",ylab="# Incorrect joins",xlim=c(0,6000),ylim=c(0,1100));

legend(000,1100,"ABySS",col=colors[1],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,1070,"Bambus",col=colors[2],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,1040,"MIP",col=colors[3],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,1010,"OPERA",col=colors[4],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,980,"SCARPA",col=colors[5],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,950,"SGA",col=colors[6],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,920,"SOAPdenovo2",col=colors[7],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,890,"SOPRA",col=colors[8],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,860,"SSPACE",col=colors[9],lty=1,lwd=2,bty="n",cex=0.7);
legend(000,830,"SWALO",col=colors[10],lty=1,lwd=2,bty="n",cex=0.7);

legend(1800,1100,"Bowtie -v 0",pch=16,bty="n",cex=0.7);
legend(1800,1070,"Bowtie -v 3",pch=17,bty="n",cex=0.7);
legend(1800,1040,"Bowtie 2",pch=15,bty="n",cex=0.7);
legend(1800,1010,"BWA",pch=18,bty="n",cex=0.7);
legend(1800,980,"abyss-map",pch=0,bty="n",cex=0.7);
legend(1800,950,"SOAP2",pch=6,bty="n",cex=0.7);

dev.off();
