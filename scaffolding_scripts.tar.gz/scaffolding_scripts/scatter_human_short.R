input=read.table("human_short_results.csv",sep=",");
colors=c("cyan","seagreen","black","red","blue","seagreen1","magenta","brown","orange","azure4");
for(i in 1:nrow(input))
{
	if(input[i,3]==3)
	{
		input[i,3]=15;
	}
	else if(input[i,3]==1)
	{
		input[i,3]=16;
	}
	else if(input[i,3]==2)
	{
		input[i,3]=17;
	}
	else if(input[i,3]==4)
	{
		input[i,3]=18;
	}
	else if(input[i,3]==5)
	{
		input[i,3]=1;
	}
}

postscript("scatter_human_short.eps");

plot(input[,4],input[,5],lwd=2,pch=input[,3],col=colors[input[,2]],xlab="# Correct joins",ylab="# Incorrect joins",xlim=c(4000,16000),ylim=c(0,600));

legend(4000,600,"ABySS",col=colors[1],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,580,"Bambus",col=colors[2],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,560,"MIP",col=colors[3],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,540,"OPERA",col=colors[4],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,520,"SCARPA",col=colors[5],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,500,"SGA",col=colors[6],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,480,"SOAPdenovo2",col=colors[7],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,460,"SOPRA",col=colors[8],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,440,"SSPACE",col=colors[9],lty=1,lwd=2,bty="n",cex=0.7);
legend(4000,420,"SWALO",col=colors[10],lty=1,lwd=2,bty="n",cex=0.7);

legend(8000,600,"Bowtie -v 0",pch=16,bty="n",cex=0.7);
legend(8000,580,"Bowtie -v 3",pch=17,bty="n",cex=0.7);
legend(8000,560,"Bowtie 2",pch=15,bty="n",cex=0.7);
legend(8000,540,"Bowtie 2 (separately)",pch=12,bty="n",cex=0.7);
legend(8000,520,"BWA",pch=18,bty="n",cex=0.7);
legend(8000,500,"abyss-map",pch=0,bty="n",cex=0.7);
legend(8000,480,"SOAP2",pch=6,bty="n",cex=0.7);

dev.off();
