input=read.table("pf_short_results.csv",sep=",");
colors=c("cyan","seagreen","black","red","blue","seagreen1","magenta","brown","orange","azure4");
for(i in 1:nrow(input))
{
	if(input[i,3]==3)
	{
		input[i,3]=15;
	}
	else if(input[i,3]==1)
	{
		input[i,3]=16;
	}
	else if(input[i,3]==2)
	{
		input[i,3]=17;
	}
	else if(input[i,3]==4)
	{
		input[i,3]=18;
	}
	else if(input[i,3]==5)
	{
		input[i,3]=1;
	}
}
postscript("scatter_pf_short.eps");

plot(input[,4],input[,5],lwd=2,pch=input[,3],col=colors[input[,2]],xlab="# Correct joins",ylab="# Incorrect joins",xlim=c(2000,6000),ylim=c(0,500));

legend(2000,500,"ABySS",col=colors[1],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,480,"Bambus",col=colors[2],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,460,"MIP",col=colors[3],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,440,"OPERA",col=colors[4],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,420,"SCARPA",col=colors[5],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,400,"SGA",col=colors[6],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,380,"SOAPdenovo2",col=colors[7],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,360,"SOPRA",col=colors[8],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,340,"SSPACE",col=colors[9],lty=1,lwd=2,bty="n",cex=0.7);
legend(2000,320,"SWALO",col=colors[10],lty=1,lwd=2,bty="n",cex=0.7);

legend(3000,500,"Bowtie -v 0",pch=16,bty="n",cex=0.7);
legend(3000,480,"Bowtie -v 3",pch=17,bty="n",cex=0.7);
legend(3000,460,"Bowtie 2",pch=15,bty="n",cex=0.7);
legend(3000,440,"BWA",pch=18,bty="n",cex=0.7);
legend(3000,420,"abyss-map",pch=0,bty="n",cex=0.7);
legend(3000,400,"SOAP2",pch=6,bty="n",cex=0.7);

dev.off();
