input=read.table("saureus_gage_results.csv",sep=",");
colors=c("cyan","darkgreen","black","red","blue","seagreen1","magenta","brown","orange","azure4");

for(i in 1:nrow(input))
{
	if(input[i,3]==3)
	{
		input[i,3]=15;
	}
	else if(input[i,3]==1)
	{
		input[i,3]=16;
	}
	else if(input[i,3]==2)
	{
		input[i,3]=17;
	}
	else if(input[i,3]==4)
	{
		input[i,3]=18;
	}
	else if(input[i,3]==5)
	{
		input[i,3]=1;
	}
}
postscript("scatter_saureus.eps");
plot(input[,4],input[,5],lwd=2,pch=input[,3],col=colors[input[,2]],xlab="# Correct joins",ylab="# Incorrect joins");

#points(input[,4],input[,5], pch=16,cex=2, lwd=0, col=adjustcolor(colors[input[,2]], alpha=0.1));



legend(1,16,"ABySS",col=colors[1],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,15.5,"Bambus",col=colors[2],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,15,"MIP",col=colors[3],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,14.5,"OPERA",col=colors[4],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,14,"SCARPA",col=colors[5],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,13.5,"SGA",col=colors[6],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,13,"SOAPdenovo2",col=colors[7],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,12.5,"SOPRA",col=colors[8],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,12,"SSPACE",col=colors[9],lty=1,lwd=2,bty="n",cex=0.7);
legend(1,11.5,"SWALO",col=colors[10],lty=1,lwd=2,bty="n",cex=0.7);

legend(30,16,"Bowtie -v 0",pch=16,bty="n",cex=0.7);
legend(30,15.5,"Bowtie -v 3",pch=17,bty="n",cex=0.7);
legend(30,15,"Bowtie 2",pch=15,bty="n",cex=0.7);
legend(30,14.5,"BWA",pch=18,bty="n",cex=0.7);
legend(30,14,"abyss-map",pch=0,bty="n",cex=0.7);
legend(30,13.5,"SOAP2",pch=6,bty="n",cex=0.7);

dev.off();