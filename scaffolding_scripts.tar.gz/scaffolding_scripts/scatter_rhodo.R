input=read.table("rhodo_gage_results.csv",sep=",");
colors=c("cyan","seagreen","black","red","blue","seagreen1","magenta","brown","orange","azure4");

for(i in 1:nrow(input))
{
	if(input[i,3]==3)
	{
		input[i,3]=15;
	}
	else if(input[i,3]==1)
	{
		input[i,3]=16;
	}
	else if(input[i,3]==2)
	{
		input[i,3]=17;
	}
	else if(input[i,3]==4)
	{
		input[i,3]=18;
	}
	else if(input[i,3]==5)
	{
		input[i,3]=1;
	}
}
postscript("scatter_rhodo.eps");
plot(input[,4],input[,5],lwd=2,pch=input[,3],col=colors[input[,2]],xlab="# Correct joins",ylab="# Incorrect joins",xlim=c(150,500));

legend(152,36,"ABySS",col=colors[1],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,35,"Bambus",col=colors[2],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,34,"MIP",col=colors[3],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,33,"OPERA",col=colors[4],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,32,"SCARPA",col=colors[5],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,31,"SGA",col=colors[6],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,30,"SOAPdenovo2",col=colors[7],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,29,"SOPRA",col=colors[8],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,28,"SSPACE",col=colors[9],lty=1,lwd=2,bty="n",cex=0.7);
legend(152,27,"SWALO",col=colors[10],lty=1,lwd=2,bty="n",cex=0.7);

legend(250,36,"Bowtie -v 0",pch=16,bty="n",cex=0.7);
legend(250,35,"Bowtie -v 3",pch=17,bty="n",cex=0.7);
legend(250,34,"Bowtie 2",pch=15,bty="n",cex=0.7);
legend(250,33,"BWA",pch=18,bty="n",cex=0.7);
legend(250,32,"abyss-map",pch=0,bty="n",cex=0.7);
legend(250,31,"SOAP2",pch=6,bty="n",cex=0.7);

dev.off();